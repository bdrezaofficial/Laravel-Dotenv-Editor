<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is no backup available exception class.
 */
class NoBackupAvailableException extends \Exception
{
    //
}
