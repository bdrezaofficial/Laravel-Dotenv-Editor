<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is invalid value exception class.
 */
class InvalidValueException extends \Exception
{
    //
}
