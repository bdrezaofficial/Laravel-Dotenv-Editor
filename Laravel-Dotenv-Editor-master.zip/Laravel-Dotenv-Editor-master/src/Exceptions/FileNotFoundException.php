<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is file not found exception class.
 */
class FileNotFoundException extends \Exception
{
    //
}
