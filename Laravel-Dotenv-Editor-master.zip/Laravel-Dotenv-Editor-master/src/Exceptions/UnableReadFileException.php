<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is unable read file exception class.
 */
class UnableReadFileException extends \Exception
{
    //
}
