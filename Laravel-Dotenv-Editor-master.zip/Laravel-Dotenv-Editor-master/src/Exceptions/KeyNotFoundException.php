<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is key not found exception class.
 */
class KeyNotFoundException extends \Exception
{
    //
}
