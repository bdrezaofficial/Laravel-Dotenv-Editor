<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is unable write to file exception class.
 */
class UnableWriteToFileException extends \Exception
{
    //
}
