<?php

namespace Jackiedo\DotenvEditor\Exceptions;

use Exception;

/**
 * This is invalid key exception class.
 */
class InvalidKeyException extends \Exception
{
    //
}
