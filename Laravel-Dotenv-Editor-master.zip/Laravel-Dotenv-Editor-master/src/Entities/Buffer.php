<?php

namespace Jackiedo\DotenvEditor\Entities;

use Illuminate\Support\Collection;

class Buffer extends Collection
{
    // code
}
